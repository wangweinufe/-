# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
import uuid

def dbHandle():
    conn = pymysql.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        passwd='2016@sureserver',
        charset='utf8',
        use_unicode=False
    )
    return conn

class MysqlPipeline(object):
    def process_item(self, item, spider):
        try:
            dbObject = dbHandle()
            cursor = dbObject.cursor()
            url = str(item['url'])
            title = str(item['title'])
            price = str(item['price'])
            comment = str(item['comment'])
            key = str(item['key'])
            besiness = str(item['besiness'])
            uuidVal = str(uuid.uuid1())
            unitprice = str(item['unitprice'])
            sql = 'insert into python.busiinfo_tea_jd(id,url,title,price,comment,type,besiness,unitprice) value (%s,%s,%s,%s,%s,%s,%s,%s)'
            cursor.execute(sql,(uuidVal,url,title,price,comment,key,besiness,unitprice))
            dbObject.commit()
        except Exception as e:
            print(e)
            dbObject.rollback()
        return item
