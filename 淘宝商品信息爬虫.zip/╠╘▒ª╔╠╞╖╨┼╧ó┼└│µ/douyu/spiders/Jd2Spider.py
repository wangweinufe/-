
import re
import urllib.request
import scrapy
import hashlib
from scrapy.http import FormRequest, Request
from scrapy.utils.project import get_project_settings
from douyu.items import DouyuItem
settings = get_project_settings;
class PhoneSpider(scrapy.Spider):
    name = "jd2"
    allowed_domains = ["jd.com"]
    start_urls = ['https://search.jd.com']
    inputword = input("请输入搜索关键字（多个关键字用空格分隔）:")
    title = "";
    #handle_httpstatus_list = [404, 403]
    offset = 200
    url = "https://search.jd.com/Search?keyword=" + inputword + "&enc=utf-8&page=" + str(offset)
    start_urls = [url]

    # 爬虫的起点
    def start_requests(self):
        # 带着cookie向网站服务器发请求，表明我们是一个已登录的用户
        yield Request(self.start_urls[0], callback=self.parse)

    # 获取100页网址
    def parse(self, response):
        try:
            for books in response.xpath('//ul[@class="gl-warp clearfix"]/li'):
                try:
                    price = books.xpath('.//div[1]/div[3]/strong[1]/i[1]/text()').extract()[0]
                except Exception as e:
                    price = ""
                try:
                    url = books.xpath('.//div[1]/div[4]/a[1]/@href').extract()[0]
                except Exception as e:
                    url = ""
                    print(e)
                try:
                    comment = books.xpath('.//div[1]/div[5]/strong[1]/a[1]/text()').extract()[0]
                except Exception as e:
                    comment = ""
                    print(comment+"333------"+str(e))
                try:
                    besiness = books.xpath('.//div[1]/div[7]/span[1]/a[1]/text()').extract()[0]
                except Exception as e:
                    besiness = ""
                    print(besiness + "222------" + str(e))
                try:
                    title = books.xpath('.//div[1]/div[4]/a[1]/em[1]').extract()[0]
                except Exception as e:
                    title = ""
                    print(title + "111------" + str(e))
                dr = re.compile(r'<[^>]+>', re.S)
                title = dr.sub('', title)
                weights = re.findall(r"(\d+)g",title)
                utilprice = 0
                if weights:
                    weights[0]
                else:
                    weights= re.findall(r"(\d+)克",title)
                if weights:
                    weight = weights[0]
                    try:
                        utilprice = float(price) / float(weight) * 500
                    except Exception as e:
                        utilprice = 0;
                        print(e)
                    utilprice = round(utilprice, 2)
                item = DouyuItem()
                item["url"] = url
                item["title"] = title
                item["price"] = price
                if utilprice !=0:
                    item["unitprice"] = utilprice
                else:
                    item["unitprice"] = price
                item["comment"] = comment
                item["besiness"] = besiness
                item["key"] = self.inputword
                yield item
        except Exception as e:
            print(e)
        if self.offset<=600:
            self.offset += 1
            self.url = "https://search.jd.com/Search?keyword=" + self.inputword + "&enc=utf-8&page=" + str(self.offset)
            print("self.url:" + self.url)
            yield scrapy.Request(self.url, callback=self.parse)