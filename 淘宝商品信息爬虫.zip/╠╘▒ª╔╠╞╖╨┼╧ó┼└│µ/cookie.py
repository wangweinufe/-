# -*- coding: utf-8 -*-
import sys
class transCookie:
    def __init__(self, cookie):
        self.cookie = cookie

    def stringToDict(self):
        '''
        将从浏览器上Copy来的cookie字符串转化为Scrapy能使用的Dict
        :return:
        '''
        itemDict = {}
        items = self.cookie.split(';')
        for item in items:
            key = item.split('=')[0].replace(' ', '')
            value = item.split('=')[1]
            itemDict[key] = value
        return itemDict

if __name__ == "__main__":
    #cookie = "TYCID=9b3ab170eb9c11e7a7c8c7af1b4972ee; undefined=9b3ab170eb9c11e7a7c8c7af1b4972ee; ssuid=9323405464; RTYCID=a2aa4bcce6014fbfb41ca38dfbe84643; aliyungf_tc=AQAAACqZnytntgQAbH8nd13g+XcdAVVs; csrfToken=0a2uoWjpnoyn4PCkgn7uJCaY; token=3cf7e8803dd14b48b51f35efecf2e899; _utm=71423f93e059449ca86d8fb1bcdef3eb; jsid=SEM-BAIDU-PZPC-000000; tyc-user-info=%257B%2522token%2522%253A%2522eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxNTExMTE2MDkxMCIsImlhdCI6MTUxNDUyODUwOCwiZXhwIjoxNTMwMDgwNTA4fQ.pGJ6fJRvF5cHl7CF9_EYK_ctDgsmMcIR3iKLEVNid1GS98CW1gs43_Eq5XdHXw9k8j1ThyDP91HmvCDPtPwhPA%2522%252C%2522integrity%2522%253A%25220%2525%2522%252C%2522state%2522%253A%25220%2522%252C%2522vipManager%2522%253A%25220%2522%252C%2522vnum%2522%253A%25220%2522%252C%2522onum%2522%253A%25220%2522%252C%2522mobile%2522%253A%252215111160910%2522%257D; auth_token=eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxNTExMTE2MDkxMCIsImlhdCI6MTUxNDUyODUwOCwiZXhwIjoxNTMwMDgwNTA4fQ.pGJ6fJRvF5cHl7CF9_EYK_ctDgsmMcIR3iKLEVNid1GS98CW1gs43_Eq5XdHXw9k8j1ThyDP91HmvCDPtPwhPA; bannerFlag=true; OA=4AaxkVNudt9qWtoS1Kpohfa4mUXQ8JJedK8vgSLwnWqxOSJ6okBbuxl1wZ8sVknGC/WSjQMIrnZaVlb/bMrk6g==; Hm_lvt_e92c8d65d92d534b0fc290df538b4758=1514515425,1514519088,1514519096,1514526775; Hm_lpvt_e92c8d65d92d534b0fc290df538b4758=1514529980; _csrf=jkxye/CK7tmuuQdBeVKrMA==; _csrf_bk=23d7551629ffd7ecbfd68be789ba9781"
    #trans = transCookie(cookie)
    print("--------------"+str(sys.path))
    #print(trans.stringToDict())